package com.telstra.restservice.controller;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.tools.JavaFileObject;

import org.json.JSONException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.boot.json.JacksonJsonParser;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

/*
 *  Request for top 10 results 
 *  http://localhost:8080/find?number=10
 */

@RestController
public class Controller {
	
	@GetMapping(value="/find")
	public ResponseEntity<Object> fun(@RequestParam("number") int number) throws IOException, ParseException
	{
		URL url = new URL("https://api.github.com/search/repositories?q=created:>2018-07-15&sort=stars&order=desc");
		HttpURLConnection conn = (HttpURLConnection)url.openConnection();
		conn.setRequestMethod("GET");
		conn.connect(); 
		int responsecode = conn.getResponseCode();
		List<JSONObject> entities = new ArrayList<JSONObject>();
		if(responsecode==200)
		{
			Scanner sc = new Scanner(url.openStream());
			String inline = new String();
			inline=sc.nextLine();
			int x=0;
			/*while(sc.hasNext())
			{
              inline+=sc.nextLine();
              x++;
              System.out.println("\n"+x);
            }*/
			sc.close();
			JSONParser parse = new JSONParser();
			JSONObject jobj = (JSONObject)parse.parse(inline); 
			entities=findResults(jobj,number);
		}
		return new ResponseEntity<Object>(entities, HttpStatus.OK);
	}
List<JSONObject> findResults(JSONObject jobj, int topresults) throws JsonProcessingException, IOException
	{
		JSONArray jsonarr = (JSONArray) jobj.get("items"); 
		List<JSONObject> entities = null;
		for(int i=0;i<topresults&&i<jsonarr.size();i++) 
		{   
			JSONObject newJsonObject=null;
			ObjectMapper mapper = new ObjectMapper();
			JSONObject jsonobj_i =  (JSONObject) jsonarr.get(i);
			System.out.println("TOP HTML_URL "+(i+1)+" :"+jsonobj_i.get("html_url"));    // fetched successfully
//			newJsonObject.put("html_url",jsonobj_i.get("html_url"));  //line 77 its not putting html_url into object
/*			newJsonObject.put("watchers_count",jsonobj_i.get("watchers_count")); //not fetching 
			newJsonObject.put("language",jsonobj_i.get("language"));			 //not fetching 
			newJsonObject.put("description",jsonobj_i.get("description"));		//not fetching 
			newJsonObject.put("name",jsonobj_i.get("name"));					//not fetching 
*/			
			//entities.add(newJsonObject);
		}
		return entities;
	}
}
