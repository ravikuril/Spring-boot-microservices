package com.telstra.restservice.service;

import org.apache.log4j.Logger;
//import org.junit.jupiter.api.Test;
import org.springframework.stereotype.Component;

import com.telstra.restservice.controller.UserController;
import com.telstra.restservice.entity.User;
import com.telstra.restservice.repository.UserRepository;

@Component
public class UserRepositoryImplementation {

	static Logger log = Logger.getLogger(UserController.class);
	
	public Iterable<User> RetriveAllUserData(UserRepository repository){
    	log.info("All user data is fetched");
        return repository.findAll();
    }

	public User SearchByUsername(String username, UserRepository repository) 
    {
        log.info("User Data is fetched by username"+username);
    	return repository.findOne(username);
    }

    public User InsertUserData(User user, UserRepository repository) 
    {
    	log.info("New User details are entered successfully");
        return repository.save(user);
    }

    public void DeleteUsername(String username, UserRepository repository) 
    {
    	log.info(username +" User's details are deleted successfully");     
    	repository.delete(username);
    }


}
