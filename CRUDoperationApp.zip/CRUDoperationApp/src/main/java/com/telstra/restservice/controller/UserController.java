package com.telstra.restservice.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.telstra.restservice.entity.User;
import com.telstra.restservice.repository.UserRepository;
import com.telstra.restservice.service.UserRepositoryImplementation;

@RestController
public class UserController {

	
    @Autowired
    private UserRepository repository;
    @Autowired
    private UserRepositoryImplementation serviceLayerObject;

    @GetMapping(path = "/users")
    public Iterable<User> RetriveAllUserDatafun()
    {
    	return serviceLayerObject.RetriveAllUserData(repository);

    }
    
    @GetMapping(path = "/{username}")
    public User SearchByUsernamefun(@PathVariable("username") String username) 
    {
    	return serviceLayerObject.SearchByUsername(username,repository);
    }
    
    @PostMapping(consumes = "application/json")
    public User InsertUserDatafun(@RequestBody User user) 
    {
    	return serviceLayerObject.InsertUserData(user,repository);
    }
   
    @DeleteMapping(path = "/{username}")
    public void DeleteUsernamefun(@PathVariable("username") String username) 
    {
    	serviceLayerObject.DeleteUsername(username,repository);
    	
    }
   
}
