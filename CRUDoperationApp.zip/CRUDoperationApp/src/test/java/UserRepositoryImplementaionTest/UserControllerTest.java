package UserRepositoryImplementaionTest;
import static org.junit.Assert.assertTrue;

import org.aspectj.lang.annotation.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
/*import org.mockito.InjectMocks;
import org.mockito.Mock;*/
import org.springframework.beans.factory.annotation.Autowired;

import com.telstra.restservice.controller.UserController;
import com.telstra.restservice.repository.UserRepository;
import com.telstra.restservice.service.UserRepositoryImplementation;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserControllerTest{
		
	/*   @InjectMocks 
	   UserController usercontroller;
	   
	   private MockMvc mockmvc;
	   */
	   @Autowired
	   UserRepository userrepository;
		
	   @Autowired
	   UserRepositoryImplementation userrepositoryimplementation;
		/*
	   @Before
	   public void setUp() throws Exception
	   {

		   MockMvc=MockMvcBuilders.standaloneSetup(UserController)
				   .build();
	   }*/
	   
	   @Test
	   public void testController() throws Exception
	   {
//		   mockMvc.perform(get("/users"))
//  			.andexcept(status().isOk());
//		   
		   //assertTrue(userrepositoryimplementation.RetriveAllUserData(userrepository));	
		   
		   String actual = "{username: \"User2\",password: \"userpassword\",name: \"Amit\",\r\n" + 
		   		"		        email: \"amit13@gmail.com\"}";
		   JSONAssert.assertNotEquals(
				   userrepositoryimplementation.SearchByUsername("User2", userrepository).toString(), actual, JSONCompareMode.LENIENT);
		  
		   /*assertTrue(userrepositoryimplementation.InsertUserData(User user, userrepository));
		   assertTrue(userrepositoryimplementation.DeleteUsername("User3", userrepository));*/
	   }
	   
}
	