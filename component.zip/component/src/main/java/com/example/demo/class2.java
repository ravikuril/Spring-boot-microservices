package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class class2 {

	public class2() 
	{
		System.out.println("C2 object");
	}
	public void m1() 
	{
		System.out.println("Class2 M1 is called");
	}
}
