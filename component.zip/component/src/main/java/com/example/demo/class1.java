package com.example.demo;

import org.springframework.stereotype.Component;

@Component("label")
public class class1 {

	public class1() 
	{
		System.out.println("C1 object");
	}
	public void m1() 
	{
		System.out.println("Class1 M1 is called");
	}
}
