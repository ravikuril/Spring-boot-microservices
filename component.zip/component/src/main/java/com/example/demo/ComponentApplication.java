package com.example.demo;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class ComponentApplication {

	public static void main(String[] args) {
//		ApplicationContext context=
//				SpringApplication.run(config.class, args);
//		
		// for component use below application context 
		AnnotationConfigApplicationContext ctx=
				new AnnotationConfigApplicationContext();
		ctx.scan("com.example.demo");
		ctx.refresh();
		
		
		class1 obj1=ctx.getBean(class1.class);
		obj1.m1();
		class2 obj2=ctx.getBean(class2.class);
		obj2.m1();
		
		//try by label component 
		System.out.println("TRY LABEL COMPONENT");
		class1 obj3=(class1)ctx.getBean("label");
		obj3.m1();
		
	}
}
