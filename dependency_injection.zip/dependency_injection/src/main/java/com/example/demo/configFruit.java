package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;

@Configuration
public class configFruit {

	@Bean
	@Description("this is the bean of fruit destroyrer")
	public fruit_destroyer fd_object()
	{
		return new fruit_destroyer();
	}
	@Bean
	
	public fruit_eater fe_object() 
	{
		return new fruit_eater();
	}
}
