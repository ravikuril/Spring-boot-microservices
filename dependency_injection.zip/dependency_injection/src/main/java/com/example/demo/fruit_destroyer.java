package com.example.demo;

import org.springframework.stereotype.Service;


public class fruit_destroyer implements fruit {

	public void apple(){
		System.out.println("DISTROYED THE FRUITS");
	}
	
	
}
