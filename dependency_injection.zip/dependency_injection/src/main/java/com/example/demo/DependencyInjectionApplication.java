package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class DependencyInjectionApplication {

	public static void main(String[] args) {
		ApplicationContext context=
				SpringApplication.run(configFruit.class);
		System.out.println("THIS IS DEPENDENCY INJECTION EXAMPLE");
		
		
		fruit_eater fe=context.getBean(fruit_eater.class);
		fe.donate_to_destroyer();
		 
	}
}
