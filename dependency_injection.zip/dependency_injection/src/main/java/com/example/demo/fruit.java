package com.example.demo;

public interface fruit {
 public void apple();
}
