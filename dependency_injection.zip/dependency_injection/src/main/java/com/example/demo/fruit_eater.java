package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


public class fruit_eater {
	//instance of fruit interface which is implemented by fruit destroyer 
	@Autowired
	private fruit fruit_ins;
	
	
	/*public void setfruit(fruit fruit_inst) 
	{
		this.fruit_ins=fruit_inst;
	}*/
	public void donate_to_destroyer() 
	{
		fruit_ins.apple();
	}

}
